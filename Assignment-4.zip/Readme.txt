

The zip folder contains the following files

1. Assignment-4.docx which contains documentation of all 6 questions.

2. Assignment-4(SSIS) folder contains SSIS package for all questions.

3. Archive.txt file contains output data in txt format after using multicast function on staging table.

4. Medicare Files folder contains Files for (Copy of Medicare_Part_D_Opioid_Prescribing_Geographic.txt files for year 2013, 2014, 2015 and 2016)
